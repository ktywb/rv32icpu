$ncverilog -s +access+rwc  mux_test.v +tcl+shm.tcl
