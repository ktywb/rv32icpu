#!/bin/bash

mkdir temp
mv ./Contents ./temp
cp ./gtkwave ./temp/Contents/MacOS
mv ./temp ./gtkwave.app